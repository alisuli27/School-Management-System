﻿namespace school_managment_system.Forms
{
    partial class Manage_users
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Manage_users));
            this.metroStyleManager1 = new MetroFramework.Components.MetroStyleManager(this.components);
            this.metroTile5 = new MetroFramework.Controls.MetroTile();
            this.metroLabel1 = new MetroFramework.Controls.MetroLabel();
            this.metroGrid1 = new MetroFramework.Controls.MetroGrid();
            this.update_panel = new MetroFramework.Controls.MetroPanel();
            this.type_combobox = new MetroFramework.Controls.MetroComboBox();
            this.password_box = new MetroFramework.Controls.MetroTextBox();
            this.username_box = new MetroFramework.Controls.MetroTextBox();
            this.ulastname_box = new MetroFramework.Controls.MetroTextBox();
            this.user_id_box = new MetroFramework.Controls.MetroTextBox();
            this.ufirstname_box = new MetroFramework.Controls.MetroTextBox();
            this.metroTile1 = new MetroFramework.Controls.MetroTile();
            this.te_update_btn = new MetroFramework.Controls.MetroButton();
            this.metroLabel13 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel6 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel5 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel7 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel4 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel3 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel2 = new MetroFramework.Controls.MetroLabel();
            this.metroButton1 = new MetroFramework.Controls.MetroButton();
            this.delete_tech_lnk = new MetroFramework.Controls.MetroLink();
            this.add_tech_lnk = new MetroFramework.Controls.MetroLink();
            this.refresh_lnk = new MetroFramework.Controls.MetroLink();
            this.search_box = new MetroFramework.Controls.MetroTextBox();
            this.metroLink1 = new MetroFramework.Controls.MetroLink();
            ((System.ComponentModel.ISupportInitialize)(this.metroStyleManager1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid1)).BeginInit();
            this.update_panel.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroStyleManager1
            // 
            this.metroStyleManager1.Owner = this;
            // 
            // metroTile5
            // 
            this.metroTile5.ActiveControl = null;
            this.metroTile5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.metroTile5.Location = new System.Drawing.Point(0, 534);
            this.metroTile5.Name = "metroTile5";
            this.metroTile5.Size = new System.Drawing.Size(900, 16);
            this.metroTile5.TabIndex = 63;
            this.metroTile5.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.metroTile5.TileTextFontSize = MetroFramework.MetroTileTextSize.Small;
            this.metroTile5.UseSelectable = true;
            this.metroTile5.UseStyleColors = true;
            // 
            // metroLabel1
            // 
            this.metroLabel1.AutoSize = true;
            this.metroLabel1.BackColor = System.Drawing.Color.DarkRed;
            this.metroLabel1.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel1.FontWeight = MetroFramework.MetroLabelWeight.Bold;
            this.metroLabel1.ForeColor = System.Drawing.SystemColors.AppWorkspace;
            this.metroLabel1.LabelMode = MetroFramework.Controls.MetroLabelMode.Selectable;
            this.metroLabel1.Location = new System.Drawing.Point(57, 15);
            this.metroLabel1.Name = "metroLabel1";
            this.metroLabel1.Size = new System.Drawing.Size(58, 25);
            this.metroLabel1.TabIndex = 6;
            this.metroLabel1.Text = "Users";
            this.metroLabel1.UseCustomForeColor = true;
            // 
            // metroGrid1
            // 
            this.metroGrid1.AllowUserToResizeRows = false;
            this.metroGrid1.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid1.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.metroGrid1.CellBorderStyle = System.Windows.Forms.DataGridViewCellBorderStyle.None;
            this.metroGrid1.ColumnHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.metroGrid1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle2.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(136)))), ((int)(((byte)(136)))), ((int)(((byte)(136)))));
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.metroGrid1.DefaultCellStyle = dataGridViewCellStyle2;
            this.metroGrid1.EnableHeadersVisualStyles = false;
            this.metroGrid1.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            this.metroGrid1.GridColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.metroGrid1.Location = new System.Drawing.Point(127, 113);
            this.metroGrid1.Name = "metroGrid1";
            this.metroGrid1.ReadOnly = true;
            this.metroGrid1.RowHeadersBorderStyle = System.Windows.Forms.DataGridViewHeaderBorderStyle.None;
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Segoe UI", 11F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Pixel);
            dataGridViewCellStyle3.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(174)))), ((int)(((byte)(219)))));
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.metroGrid1.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            this.metroGrid1.RowHeadersWidthSizeMode = System.Windows.Forms.DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            this.metroGrid1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.metroGrid1.Size = new System.Drawing.Size(650, 415);
            this.metroGrid1.TabIndex = 1;
            this.metroGrid1.UseStyleColors = true;
            this.metroGrid1.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.MetroGrid1_CellClick);
            this.metroGrid1.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.MetroGrid1_CellContentDoubleClick);
            // 
            // update_panel
            // 
            this.update_panel.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.update_panel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.update_panel.Controls.Add(this.type_combobox);
            this.update_panel.Controls.Add(this.password_box);
            this.update_panel.Controls.Add(this.username_box);
            this.update_panel.Controls.Add(this.ulastname_box);
            this.update_panel.Controls.Add(this.user_id_box);
            this.update_panel.Controls.Add(this.ufirstname_box);
            this.update_panel.Controls.Add(this.metroTile1);
            this.update_panel.Controls.Add(this.te_update_btn);
            this.update_panel.Controls.Add(this.metroLabel13);
            this.update_panel.Controls.Add(this.metroLabel6);
            this.update_panel.Controls.Add(this.metroLabel5);
            this.update_panel.Controls.Add(this.metroLabel7);
            this.update_panel.Controls.Add(this.metroLabel4);
            this.update_panel.Controls.Add(this.metroLabel3);
            this.update_panel.Controls.Add(this.metroLabel2);
            this.update_panel.Controls.Add(this.metroButton1);
            this.update_panel.HorizontalScrollbarBarColor = false;
            this.update_panel.HorizontalScrollbarHighlightOnWheel = false;
            this.update_panel.HorizontalScrollbarSize = 10;
            this.update_panel.Location = new System.Drawing.Point(236, 98);
            this.update_panel.Name = "update_panel";
            this.update_panel.Size = new System.Drawing.Size(462, 356);
            this.update_panel.TabIndex = 75;
            this.update_panel.VerticalScrollbarBarColor = true;
            this.update_panel.VerticalScrollbarHighlightOnWheel = false;
            this.update_panel.VerticalScrollbarSize = 10;
            this.update_panel.Visible = false;
            // 
            // type_combobox
            // 
            this.type_combobox.FormattingEnabled = true;
            this.type_combobox.ItemHeight = 23;
            this.type_combobox.Items.AddRange(new object[] {
            "Admin",
            "Staff",
            "Teacher"});
            this.type_combobox.Location = new System.Drawing.Point(205, 270);
            this.type_combobox.Name = "type_combobox";
            this.type_combobox.Size = new System.Drawing.Size(215, 29);
            this.type_combobox.TabIndex = 90;
            this.type_combobox.UseSelectable = true;
            // 
            // password_box
            // 
            this.password_box.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.password_box.Lines = new string[0];
            this.password_box.Location = new System.Drawing.Point(205, 222);
            this.password_box.MaxLength = 32767;
            this.password_box.Name = "password_box";
            this.password_box.PasswordChar = '\0';
            this.password_box.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.password_box.SelectedText = "";
            this.password_box.Size = new System.Drawing.Size(215, 23);
            this.password_box.TabIndex = 86;
            this.password_box.UseCustomBackColor = true;
            this.password_box.UseSelectable = true;
            // 
            // username_box
            // 
            this.username_box.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.username_box.Lines = new string[0];
            this.username_box.Location = new System.Drawing.Point(205, 179);
            this.username_box.MaxLength = 32767;
            this.username_box.Name = "username_box";
            this.username_box.PasswordChar = '\0';
            this.username_box.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.username_box.SelectedText = "";
            this.username_box.Size = new System.Drawing.Size(215, 23);
            this.username_box.TabIndex = 87;
            this.username_box.UseCustomBackColor = true;
            this.username_box.UseSelectable = true;
            // 
            // ulastname_box
            // 
            this.ulastname_box.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ulastname_box.Lines = new string[0];
            this.ulastname_box.Location = new System.Drawing.Point(205, 139);
            this.ulastname_box.MaxLength = 32767;
            this.ulastname_box.Name = "ulastname_box";
            this.ulastname_box.PasswordChar = '\0';
            this.ulastname_box.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.ulastname_box.SelectedText = "";
            this.ulastname_box.Size = new System.Drawing.Size(215, 23);
            this.ulastname_box.TabIndex = 88;
            this.ulastname_box.UseCustomBackColor = true;
            this.ulastname_box.UseSelectable = true;
            // 
            // user_id_box
            // 
            this.user_id_box.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.user_id_box.Enabled = false;
            this.user_id_box.Lines = new string[0];
            this.user_id_box.Location = new System.Drawing.Point(205, 56);
            this.user_id_box.MaxLength = 32767;
            this.user_id_box.Name = "user_id_box";
            this.user_id_box.PasswordChar = '\0';
            this.user_id_box.ReadOnly = true;
            this.user_id_box.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.user_id_box.SelectedText = "";
            this.user_id_box.Size = new System.Drawing.Size(215, 23);
            this.user_id_box.TabIndex = 1;
            this.user_id_box.UseCustomBackColor = true;
            this.user_id_box.UseSelectable = true;
            // 
            // ufirstname_box
            // 
            this.ufirstname_box.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.ufirstname_box.Lines = new string[0];
            this.ufirstname_box.Location = new System.Drawing.Point(205, 95);
            this.ufirstname_box.MaxLength = 32767;
            this.ufirstname_box.Name = "ufirstname_box";
            this.ufirstname_box.PasswordChar = '\0';
            this.ufirstname_box.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.ufirstname_box.SelectedText = "";
            this.ufirstname_box.Size = new System.Drawing.Size(215, 23);
            this.ufirstname_box.TabIndex = 89;
            this.ufirstname_box.UseCustomBackColor = true;
            this.ufirstname_box.UseSelectable = true;
            // 
            // metroTile1
            // 
            this.metroTile1.ActiveControl = null;
            this.metroTile1.Dock = System.Windows.Forms.DockStyle.Top;
            this.metroTile1.Location = new System.Drawing.Point(0, 0);
            this.metroTile1.Name = "metroTile1";
            this.metroTile1.Size = new System.Drawing.Size(460, 5);
            this.metroTile1.TabIndex = 62;
            this.metroTile1.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.metroTile1.TileTextFontSize = MetroFramework.MetroTileTextSize.Small;
            this.metroTile1.UseSelectable = true;
            this.metroTile1.UseStyleColors = true;
            // 
            // te_update_btn
            // 
            this.te_update_btn.Location = new System.Drawing.Point(345, 311);
            this.te_update_btn.Name = "te_update_btn";
            this.te_update_btn.Size = new System.Drawing.Size(75, 23);
            this.te_update_btn.TabIndex = 71;
            this.te_update_btn.Text = "&Update";
            this.te_update_btn.UseSelectable = true;
            this.te_update_btn.Click += new System.EventHandler(this.Te_update_btn_Click);
            // 
            // metroLabel13
            // 
            this.metroLabel13.AutoSize = true;
            this.metroLabel13.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel13.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel13.Location = new System.Drawing.Point(52, 284);
            this.metroLabel13.Name = "metroLabel13";
            this.metroLabel13.Size = new System.Drawing.Size(36, 15);
            this.metroLabel13.TabIndex = 70;
            this.metroLabel13.Text = "Type:";
            // 
            // metroLabel6
            // 
            this.metroLabel6.AutoSize = true;
            this.metroLabel6.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel6.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel6.Location = new System.Drawing.Point(52, 230);
            this.metroLabel6.Name = "metroLabel6";
            this.metroLabel6.Size = new System.Drawing.Size(60, 15);
            this.metroLabel6.TabIndex = 70;
            this.metroLabel6.Text = "Password:";
            // 
            // metroLabel5
            // 
            this.metroLabel5.AutoSize = true;
            this.metroLabel5.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel5.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel5.Location = new System.Drawing.Point(52, 187);
            this.metroLabel5.Name = "metroLabel5";
            this.metroLabel5.Size = new System.Drawing.Size(63, 15);
            this.metroLabel5.TabIndex = 70;
            this.metroLabel5.Text = "Username:";
            // 
            // metroLabel7
            // 
            this.metroLabel7.AutoSize = true;
            this.metroLabel7.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel7.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel7.Location = new System.Drawing.Point(52, 64);
            this.metroLabel7.Name = "metroLabel7";
            this.metroLabel7.Size = new System.Drawing.Size(46, 15);
            this.metroLabel7.TabIndex = 70;
            this.metroLabel7.Text = "User Id:";
            // 
            // metroLabel4
            // 
            this.metroLabel4.AutoSize = true;
            this.metroLabel4.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel4.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel4.Location = new System.Drawing.Point(52, 147);
            this.metroLabel4.Name = "metroLabel4";
            this.metroLabel4.Size = new System.Drawing.Size(61, 15);
            this.metroLabel4.TabIndex = 70;
            this.metroLabel4.Text = "Lastname:";
            // 
            // metroLabel3
            // 
            this.metroLabel3.AutoSize = true;
            this.metroLabel3.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel3.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel3.Location = new System.Drawing.Point(52, 103);
            this.metroLabel3.Name = "metroLabel3";
            this.metroLabel3.Size = new System.Drawing.Size(62, 15);
            this.metroLabel3.TabIndex = 70;
            this.metroLabel3.Text = "Firstname:";
            // 
            // metroLabel2
            // 
            this.metroLabel2.AutoSize = true;
            this.metroLabel2.FontSize = MetroFramework.MetroLabelSize.Tall;
            this.metroLabel2.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel2.Location = new System.Drawing.Point(25, 9);
            this.metroLabel2.Name = "metroLabel2";
            this.metroLabel2.Size = new System.Drawing.Size(110, 25);
            this.metroLabel2.TabIndex = 69;
            this.metroLabel2.Text = "Update User";
            // 
            // metroButton1
            // 
            this.metroButton1.BackColor = System.Drawing.Color.Red;
            this.metroButton1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.metroButton1.FontSize = MetroFramework.MetroButtonSize.Medium;
            this.metroButton1.FontWeight = MetroFramework.MetroButtonWeight.Regular;
            this.metroButton1.Location = new System.Drawing.Point(430, 4);
            this.metroButton1.Name = "metroButton1";
            this.metroButton1.Size = new System.Drawing.Size(30, 24);
            this.metroButton1.TabIndex = 96;
            this.metroButton1.Text = "X";
            this.metroButton1.UseCustomBackColor = true;
            this.metroButton1.UseSelectable = true;
            this.metroButton1.Click += new System.EventHandler(this.MetroButton1_Click);
            // 
            // delete_tech_lnk
            // 
            this.delete_tech_lnk.BackgroundImage = global::school_managment_system.Properties.Resources.delete_user_grey;
            this.delete_tech_lnk.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.delete_tech_lnk.Cursor = System.Windows.Forms.Cursors.Hand;
            this.delete_tech_lnk.Location = new System.Drawing.Point(720, 75);
            this.delete_tech_lnk.Name = "delete_tech_lnk";
            this.delete_tech_lnk.Size = new System.Drawing.Size(75, 37);
            this.delete_tech_lnk.TabIndex = 4;
            this.delete_tech_lnk.UseSelectable = true;
            this.delete_tech_lnk.Click += new System.EventHandler(this.Delete_tech_lnk_Click);
            this.delete_tech_lnk.MouseLeave += new System.EventHandler(this.Delete_tech_lnk_MouseLeave);
            this.delete_tech_lnk.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Delete_tech_lnk_MouseMove);
            // 
            // add_tech_lnk
            // 
            this.add_tech_lnk.BackgroundImage = global::school_managment_system.Properties.Resources.add_user_grey;
            this.add_tech_lnk.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.add_tech_lnk.Cursor = System.Windows.Forms.Cursors.Hand;
            this.add_tech_lnk.Location = new System.Drawing.Point(649, 73);
            this.add_tech_lnk.Name = "add_tech_lnk";
            this.add_tech_lnk.Size = new System.Drawing.Size(75, 34);
            this.add_tech_lnk.TabIndex = 3;
            this.add_tech_lnk.UseSelectable = true;
            this.add_tech_lnk.Click += new System.EventHandler(this.Add_tech_lnk_Click);
            this.add_tech_lnk.MouseLeave += new System.EventHandler(this.Add_tech_lnk_MouseLeave);
            this.add_tech_lnk.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Add_tech_lnk_MouseMove);
            // 
            // refresh_lnk
            // 
            this.refresh_lnk.BackgroundImage = global::school_managment_system.Properties.Resources.refresh_grey;
            this.refresh_lnk.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.refresh_lnk.Cursor = System.Windows.Forms.Cursors.Hand;
            this.refresh_lnk.Location = new System.Drawing.Point(578, 73);
            this.refresh_lnk.Name = "refresh_lnk";
            this.refresh_lnk.Size = new System.Drawing.Size(75, 34);
            this.refresh_lnk.TabIndex = 2;
            this.refresh_lnk.UseSelectable = true;
            this.refresh_lnk.Click += new System.EventHandler(this.Refresh_lnk_Click);
            this.refresh_lnk.MouseLeave += new System.EventHandler(this.Refresh_lnk_MouseLeave);
            this.refresh_lnk.MouseMove += new System.Windows.Forms.MouseEventHandler(this.Refresh_lnk_MouseMove);
            // 
            // search_box
            // 
            this.search_box.BackColor = System.Drawing.SystemColors.ControlLightLight;
            this.search_box.Icon = ((System.Drawing.Image)(resources.GetObject("search_box.Icon")));
            this.search_box.IconRight = true;
            this.search_box.Lines = new string[0];
            this.search_box.Location = new System.Drawing.Point(129, 87);
            this.search_box.MaxLength = 32767;
            this.search_box.Name = "search_box";
            this.search_box.PasswordChar = '\0';
            this.search_box.PromptText = "search by ID";
            this.search_box.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.search_box.SelectedText = "";
            this.search_box.Size = new System.Drawing.Size(219, 23);
            this.search_box.TabIndex = 0;
            this.search_box.UseCustomBackColor = true;
            this.search_box.UseSelectable = true;
            this.search_box.TextChanged += new System.EventHandler(this.Search_box_TextChanged);
            // 
            // metroLink1
            // 
            this.metroLink1.BackColor = System.Drawing.Color.Transparent;
            this.metroLink1.BackgroundImage = global::school_managment_system.Properties.Resources.home_icon_grey;
            this.metroLink1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.metroLink1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroLink1.DisplayFocus = true;
            this.metroLink1.ForeColor = System.Drawing.Color.Transparent;
            this.metroLink1.Location = new System.Drawing.Point(0, 6);
            this.metroLink1.Name = "metroLink1";
            this.metroLink1.Size = new System.Drawing.Size(51, 34);
            this.metroLink1.TabIndex = 5;
            this.metroLink1.UseCustomForeColor = true;
            this.metroLink1.UseSelectable = true;
            this.metroLink1.Click += new System.EventHandler(this.MetroLink1_Click);
            this.metroLink1.MouseLeave += new System.EventHandler(this.MetroLink1_MouseLeave);
            this.metroLink1.MouseMove += new System.Windows.Forms.MouseEventHandler(this.MetroLink1_MouseMove);
            // 
            // Manage_users
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(900, 550);
            this.ControlBox = false;
            this.Controls.Add(this.update_panel);
            this.Controls.Add(this.metroGrid1);
            this.Controls.Add(this.delete_tech_lnk);
            this.Controls.Add(this.add_tech_lnk);
            this.Controls.Add(this.refresh_lnk);
            this.Controls.Add(this.metroLabel1);
            this.Controls.Add(this.metroLink1);
            this.Controls.Add(this.metroTile5);
            this.Controls.Add(this.search_box);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "Manage_users";
            this.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide;
            this.Load += new System.EventHandler(this.Manage_users_Load);
            ((System.ComponentModel.ISupportInitialize)(this.metroStyleManager1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.metroGrid1)).EndInit();
            this.update_panel.ResumeLayout(false);
            this.update_panel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private MetroFramework.Components.MetroStyleManager metroStyleManager1;
        private MetroFramework.Controls.MetroTile metroTile5;
        private MetroFramework.Controls.MetroTextBox search_box;
        private MetroFramework.Controls.MetroLabel metroLabel1;
        private MetroFramework.Controls.MetroLink metroLink1;
        private MetroFramework.Controls.MetroLink delete_tech_lnk;
        private MetroFramework.Controls.MetroLink add_tech_lnk;
        private MetroFramework.Controls.MetroLink refresh_lnk;
        public MetroFramework.Controls.MetroGrid metroGrid1;
        private MetroFramework.Controls.MetroPanel update_panel;
        private MetroFramework.Controls.MetroTile metroTile1;
        private MetroFramework.Controls.MetroButton te_update_btn;
        private MetroFramework.Controls.MetroLabel metroLabel13;
        private MetroFramework.Controls.MetroLabel metroLabel6;
        private MetroFramework.Controls.MetroLabel metroLabel5;
        private MetroFramework.Controls.MetroLabel metroLabel4;
        private MetroFramework.Controls.MetroLabel metroLabel3;
        private MetroFramework.Controls.MetroLabel metroLabel2;
        private MetroFramework.Controls.MetroComboBox type_combobox;
        private MetroFramework.Controls.MetroTextBox password_box;
        private MetroFramework.Controls.MetroTextBox username_box;
        private MetroFramework.Controls.MetroTextBox ulastname_box;
        private MetroFramework.Controls.MetroTextBox ufirstname_box;
        private MetroFramework.Controls.MetroTextBox user_id_box;
        private MetroFramework.Controls.MetroLabel metroLabel7;
        private MetroFramework.Controls.MetroButton metroButton1;
    }
}