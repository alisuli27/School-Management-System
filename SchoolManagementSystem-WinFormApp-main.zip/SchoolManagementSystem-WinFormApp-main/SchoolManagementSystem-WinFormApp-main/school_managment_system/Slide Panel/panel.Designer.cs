﻿namespace school_managment_system.Slide_Panel
{
    partial class panel
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.metroPanel1 = new MetroFramework.Controls.MetroPanel();
            this.metroLink1 = new MetroFramework.Controls.MetroLink();
            this.metroStyleManager1 = new MetroFramework.Components.MetroStyleManager(this.components);
            this.folderBrowserDialog1 = new System.Windows.Forms.FolderBrowserDialog();
            this.openFileDialog1 = new System.Windows.Forms.OpenFileDialog();
            this.metroTabPage4 = new MetroFramework.Controls.MetroTabPage();
            this.metroLabel12 = new MetroFramework.Controls.MetroLabel();
            this.metroLabel11 = new MetroFramework.Controls.MetroLabel();
            this.metroRadioButton1 = new MetroFramework.Controls.MetroRadioButton();
            this.metroRadioButton2 = new MetroFramework.Controls.MetroRadioButton();
            this.flowLayoutPanel2 = new System.Windows.Forms.FlowLayoutPanel();
            this.metroTabPage3 = new MetroFramework.Controls.MetroTabPage();
            this.servtxt = new MetroFramework.Controls.MetroTextBox();
            this.datatxt = new MetroFramework.Controls.MetroTextBox();
            this.usertxt = new MetroFramework.Controls.MetroTextBox();
            this.passtxt = new MetroFramework.Controls.MetroTextBox();
            this.servlbl = new MetroFramework.Controls.MetroLabel();
            this.datalbl = new MetroFramework.Controls.MetroLabel();
            this.userlbl = new MetroFramework.Controls.MetroLabel();
            this.passlbl = new MetroFramework.Controls.MetroLabel();
            this.testbtn = new MetroFramework.Controls.MetroButton();
            this.metroTabControl2 = new MetroFramework.Controls.MetroTabControl();
            this.metroPanel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.metroStyleManager1)).BeginInit();
            this.metroTabPage4.SuspendLayout();
            this.metroTabPage3.SuspendLayout();
            this.metroTabControl2.SuspendLayout();
            this.SuspendLayout();
            // 
            // metroPanel1
            // 
            this.metroPanel1.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.metroPanel1.Controls.Add(this.metroTabControl2);
            this.metroPanel1.Controls.Add(this.metroLink1);
            this.metroPanel1.HorizontalScrollbarBarColor = true;
            this.metroPanel1.HorizontalScrollbarHighlightOnWheel = false;
            this.metroPanel1.HorizontalScrollbarSize = 10;
            this.metroPanel1.Location = new System.Drawing.Point(617, 0);
            this.metroPanel1.Name = "metroPanel1";
            this.metroPanel1.Size = new System.Drawing.Size(283, 509);
            this.metroPanel1.TabIndex = 8;
            this.metroPanel1.UseStyleColors = true;
            this.metroPanel1.VerticalScrollbarBarColor = true;
            this.metroPanel1.VerticalScrollbarHighlightOnWheel = false;
            this.metroPanel1.VerticalScrollbarSize = 10;
            // 
            // metroLink1
            // 
            this.metroLink1.Cursor = System.Windows.Forms.Cursors.Hand;
            this.metroLink1.FontSize = MetroFramework.MetroLinkSize.Tall;
            this.metroLink1.FontWeight = MetroFramework.MetroLinkWeight.Regular;
            this.metroLink1.Location = new System.Drawing.Point(7, 30);
            this.metroLink1.Name = "metroLink1";
            this.metroLink1.Size = new System.Drawing.Size(111, 32);
            this.metroLink1.TabIndex = 8;
            this.metroLink1.Text = "&Settings";
            this.metroLink1.UseSelectable = true;
            this.metroLink1.Click += new System.EventHandler(this.MetroLink1_Click);
            // 
            // metroStyleManager1
            // 
            this.metroStyleManager1.Owner = this;
            // 
            // openFileDialog1
            // 
            this.openFileDialog1.FileName = "openFileDialog1";
            // 
            // metroTabPage4
            // 
            this.metroTabPage4.Controls.Add(this.flowLayoutPanel2);
            this.metroTabPage4.Controls.Add(this.metroRadioButton2);
            this.metroTabPage4.Controls.Add(this.metroRadioButton1);
            this.metroTabPage4.Controls.Add(this.metroLabel11);
            this.metroTabPage4.Controls.Add(this.metroLabel12);
            this.metroTabPage4.HorizontalScrollbarBarColor = true;
            this.metroTabPage4.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage4.HorizontalScrollbarSize = 10;
            this.metroTabPage4.Location = new System.Drawing.Point(4, 41);
            this.metroTabPage4.Name = "metroTabPage4";
            this.metroTabPage4.Size = new System.Drawing.Size(270, 371);
            this.metroTabPage4.TabIndex = 2;
            this.metroTabPage4.Text = "&Theme";
            this.metroTabPage4.VerticalScrollbarBarColor = true;
            this.metroTabPage4.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage4.VerticalScrollbarSize = 10;
            // 
            // metroLabel12
            // 
            this.metroLabel12.AutoSize = true;
            this.metroLabel12.FontSize = MetroFramework.MetroLabelSize.Small;
            this.metroLabel12.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.metroLabel12.Location = new System.Drawing.Point(24, 24);
            this.metroLabel12.Name = "metroLabel12";
            this.metroLabel12.Size = new System.Drawing.Size(47, 15);
            this.metroLabel12.TabIndex = 2;
            this.metroLabel12.Text = "Theme:";
            // 
            // metroLabel11
            // 
            this.metroLabel11.AutoSize = true;
            this.metroLabel11.Location = new System.Drawing.Point(3, 104);
            this.metroLabel11.Name = "metroLabel11";
            this.metroLabel11.Size = new System.Drawing.Size(36, 19);
            this.metroLabel11.TabIndex = 2;
            this.metroLabel11.Text = "Style";
            // 
            // metroRadioButton1
            // 
            this.metroRadioButton1.AutoSize = true;
            this.metroRadioButton1.Location = new System.Drawing.Point(24, 68);
            this.metroRadioButton1.Name = "metroRadioButton1";
            this.metroRadioButton1.Size = new System.Drawing.Size(47, 15);
            this.metroRadioButton1.TabIndex = 3;
            this.metroRadioButton1.Text = "&Dark";
            this.metroRadioButton1.UseSelectable = true;
            this.metroRadioButton1.CheckedChanged += new System.EventHandler(this.MetroRadioButton1_CheckedChanged);
            // 
            // metroRadioButton2
            // 
            this.metroRadioButton2.AutoSize = true;
            this.metroRadioButton2.Location = new System.Drawing.Point(139, 68);
            this.metroRadioButton2.Name = "metroRadioButton2";
            this.metroRadioButton2.Size = new System.Drawing.Size(50, 15);
            this.metroRadioButton2.TabIndex = 3;
            this.metroRadioButton2.Text = "&Light";
            this.metroRadioButton2.UseSelectable = true;
            this.metroRadioButton2.CheckedChanged += new System.EventHandler(this.MetroRadioButton2_CheckedChanged);
            // 
            // flowLayoutPanel2
            // 
            this.flowLayoutPanel2.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.flowLayoutPanel2.Location = new System.Drawing.Point(0, 126);
            this.flowLayoutPanel2.Name = "flowLayoutPanel2";
            this.flowLayoutPanel2.Size = new System.Drawing.Size(270, 245);
            this.flowLayoutPanel2.TabIndex = 4;
            // 
            // metroTabPage3
            // 
            this.metroTabPage3.BackColor = System.Drawing.SystemColors.Control;
            this.metroTabPage3.Controls.Add(this.testbtn);
            this.metroTabPage3.Controls.Add(this.passlbl);
            this.metroTabPage3.Controls.Add(this.userlbl);
            this.metroTabPage3.Controls.Add(this.datalbl);
            this.metroTabPage3.Controls.Add(this.servlbl);
            this.metroTabPage3.Controls.Add(this.passtxt);
            this.metroTabPage3.Controls.Add(this.usertxt);
            this.metroTabPage3.Controls.Add(this.datatxt);
            this.metroTabPage3.Controls.Add(this.servtxt);
            this.metroTabPage3.HorizontalScrollbarBarColor = true;
            this.metroTabPage3.HorizontalScrollbarHighlightOnWheel = false;
            this.metroTabPage3.HorizontalScrollbarSize = 10;
            this.metroTabPage3.Location = new System.Drawing.Point(4, 41);
            this.metroTabPage3.Name = "metroTabPage3";
            this.metroTabPage3.Size = new System.Drawing.Size(270, 371);
            this.metroTabPage3.TabIndex = 0;
            this.metroTabPage3.Text = "&Connection";
            this.metroTabPage3.VerticalScrollbarBarColor = true;
            this.metroTabPage3.VerticalScrollbarHighlightOnWheel = false;
            this.metroTabPage3.VerticalScrollbarSize = 10;
            // 
            // servtxt
            // 
            this.servtxt.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.servtxt.Lines = new string[0];
            this.servtxt.Location = new System.Drawing.Point(15, 60);
            this.servtxt.MaxLength = 32767;
            this.servtxt.Name = "servtxt";
            this.servtxt.PasswordChar = '\0';
            this.servtxt.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.servtxt.SelectedText = "";
            this.servtxt.Size = new System.Drawing.Size(244, 23);
            this.servtxt.TabIndex = 1;
            this.servtxt.UseSelectable = true;
            // 
            // datatxt
            // 
            this.datatxt.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.datatxt.Lines = new string[0];
            this.datatxt.Location = new System.Drawing.Point(15, 122);
            this.datatxt.MaxLength = 32767;
            this.datatxt.Name = "datatxt";
            this.datatxt.PasswordChar = '\0';
            this.datatxt.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.datatxt.SelectedText = "";
            this.datatxt.Size = new System.Drawing.Size(244, 23);
            this.datatxt.TabIndex = 2;
            this.datatxt.UseSelectable = true;
            // 
            // usertxt
            // 
            this.usertxt.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.usertxt.Lines = new string[0];
            this.usertxt.Location = new System.Drawing.Point(15, 184);
            this.usertxt.MaxLength = 32767;
            this.usertxt.Name = "usertxt";
            this.usertxt.PasswordChar = '\0';
            this.usertxt.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.usertxt.SelectedText = "";
            this.usertxt.Size = new System.Drawing.Size(244, 23);
            this.usertxt.TabIndex = 3;
            this.usertxt.UseSelectable = true;
            // 
            // passtxt
            // 
            this.passtxt.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.passtxt.Lines = new string[0];
            this.passtxt.Location = new System.Drawing.Point(15, 246);
            this.passtxt.MaxLength = 32767;
            this.passtxt.Name = "passtxt";
            this.passtxt.PasswordChar = '\0';
            this.passtxt.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.passtxt.SelectedText = "";
            this.passtxt.Size = new System.Drawing.Size(244, 23);
            this.passtxt.TabIndex = 4;
            this.passtxt.UseSelectable = true;
            // 
            // servlbl
            // 
            this.servlbl.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.servlbl.AutoSize = true;
            this.servlbl.FontSize = MetroFramework.MetroLabelSize.Small;
            this.servlbl.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.servlbl.Location = new System.Drawing.Point(15, 31);
            this.servlbl.Name = "servlbl";
            this.servlbl.Size = new System.Drawing.Size(77, 15);
            this.servlbl.TabIndex = 3;
            this.servlbl.Text = "Server Name:";
            // 
            // datalbl
            // 
            this.datalbl.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.datalbl.AutoSize = true;
            this.datalbl.FontSize = MetroFramework.MetroLabelSize.Small;
            this.datalbl.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.datalbl.Location = new System.Drawing.Point(15, 93);
            this.datalbl.Name = "datalbl";
            this.datalbl.Size = new System.Drawing.Size(93, 15);
            this.datalbl.TabIndex = 3;
            this.datalbl.Text = "Database Name:";
            // 
            // userlbl
            // 
            this.userlbl.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.userlbl.AutoSize = true;
            this.userlbl.FontSize = MetroFramework.MetroLabelSize.Small;
            this.userlbl.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.userlbl.Location = new System.Drawing.Point(15, 155);
            this.userlbl.Name = "userlbl";
            this.userlbl.Size = new System.Drawing.Size(63, 15);
            this.userlbl.TabIndex = 3;
            this.userlbl.Text = "Username:";
            // 
            // passlbl
            // 
            this.passlbl.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.passlbl.AutoSize = true;
            this.passlbl.FontSize = MetroFramework.MetroLabelSize.Small;
            this.passlbl.FontWeight = MetroFramework.MetroLabelWeight.Regular;
            this.passlbl.Location = new System.Drawing.Point(15, 217);
            this.passlbl.Name = "passlbl";
            this.passlbl.Size = new System.Drawing.Size(60, 15);
            this.passlbl.TabIndex = 3;
            this.passlbl.Text = "Password:";
            // 
            // testbtn
            // 
            this.testbtn.Location = new System.Drawing.Point(15, 307);
            this.testbtn.Name = "testbtn";
            this.testbtn.Size = new System.Drawing.Size(244, 23);
            this.testbtn.TabIndex = 5;
            this.testbtn.Text = "Test Connection";
            this.testbtn.UseSelectable = true;
            this.testbtn.UseStyleColors = true;
            this.testbtn.Click += new System.EventHandler(this.testbtn_Click);
            // 
            // metroTabControl2
            // 
            this.metroTabControl2.Anchor = System.Windows.Forms.AnchorStyles.Right;
            this.metroTabControl2.Appearance = System.Windows.Forms.TabAppearance.FlatButtons;
            this.metroTabControl2.Controls.Add(this.metroTabPage3);
            this.metroTabControl2.Controls.Add(this.metroTabPage4);
            this.metroTabControl2.FontWeight = MetroFramework.MetroTabControlWeight.Regular;
            this.metroTabControl2.HotTrack = true;
            this.metroTabControl2.Location = new System.Drawing.Point(3, 68);
            this.metroTabControl2.Name = "metroTabControl2";
            this.metroTabControl2.SelectedIndex = 0;
            this.metroTabControl2.Size = new System.Drawing.Size(278, 416);
            this.metroTabControl2.TabIndex = 0;
            this.metroTabControl2.UseSelectable = true;
            // 
            // panel
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.metroPanel1);
            this.Name = "panel";
            this.Size = new System.Drawing.Size(900, 509);
            this.metroPanel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.metroStyleManager1)).EndInit();
            this.metroTabPage4.ResumeLayout(false);
            this.metroTabPage4.PerformLayout();
            this.metroTabPage3.ResumeLayout(false);
            this.metroTabPage3.PerformLayout();
            this.metroTabControl2.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private MetroFramework.Controls.MetroPanel metroPanel1;
        private MetroFramework.Controls.MetroLink metroLink1;
        private MetroFramework.Components.MetroStyleManager metroStyleManager1;
        private MetroFramework.Controls.MetroTabControl metroTabControl2;
        private MetroFramework.Controls.MetroTabPage metroTabPage3;
        private MetroFramework.Controls.MetroButton testbtn;
        private MetroFramework.Controls.MetroLabel passlbl;
        private MetroFramework.Controls.MetroLabel userlbl;
        private MetroFramework.Controls.MetroLabel datalbl;
        private MetroFramework.Controls.MetroLabel servlbl;
        private MetroFramework.Controls.MetroTextBox passtxt;
        private MetroFramework.Controls.MetroTextBox usertxt;
        private MetroFramework.Controls.MetroTextBox datatxt;
        private MetroFramework.Controls.MetroTextBox servtxt;
        private MetroFramework.Controls.MetroTabPage metroTabPage4;
        private System.Windows.Forms.FlowLayoutPanel flowLayoutPanel2;
        private MetroFramework.Controls.MetroRadioButton metroRadioButton2;
        private MetroFramework.Controls.MetroRadioButton metroRadioButton1;
        private MetroFramework.Controls.MetroLabel metroLabel11;
        private MetroFramework.Controls.MetroLabel metroLabel12;
        private System.Windows.Forms.FolderBrowserDialog folderBrowserDialog1;
        private System.Windows.Forms.OpenFileDialog openFileDialog1;
    }
}
